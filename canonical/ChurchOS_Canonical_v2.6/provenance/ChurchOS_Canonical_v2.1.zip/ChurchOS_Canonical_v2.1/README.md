# ChurchOS 정본 v2.1 — 2026-10-24

이 패키지는 v2.0을 이어 수정한 현재 설계 정본(main)이다. 정본은 제품 방향의 권위를 뜻하며 구현·운영 검증 완료를 뜻하지 않는다. GitHub main 변경은 수행하지 않았다.

앱을 열면 ChurchOS(최종 브랜드명 미정)가 나온다. ChurchOS는 교회 운영과 마케팅의 중심 접점이다. 너랑나랑·생명일기·JLPrayer·JLBible·JLAcademy·CHGO는 각각 독립 제품으로 설계·개발·배포하며 API로 연결한다. 지저스라이프 원은 내부 생태계 명칭이며 스플래시·로그인·메뉴·앱 이름에 노출하지 않는다.

## 읽는 순서
1. `governance/CANONICAL.md` — 변경 권위와 정본 상태
2. `specs/01_제품정의와경계.md` — 일곱 제품의 책임
3. `architecture/01_백엔드서비스구조.md` — 독립 배포와 API 연결
4. `contracts/01_통합경계계약.md` — 제공자별 최소 데이터
5. `ux/02_핵심사용자흐름.md` — 앱 시작과 교회 업무
6. `handoff/ROADMAP.md` — 구현·검증 순서
7. `CHANGELOG.md`, `VALIDATION.json` — 변경과 실제 검사 상태

## 검사
`python -m pip install -r requirements-dev.txt`
`python tools/validate.py`
`python -m unittest discover -s tests -p 'test_*.py'`

매니페스트 경로는 이 폴더 기준이다. 과거 정적 PASS는 승계하지 않는다. PostgreSQL 16·앱·서비스·복구·파일럿은 실제 실행 전까지 NOT_RUN이다. V001~V012는 원본 바이트를 보존하고 V013을 추가했다. 기존 GitHub DB와 ZIP DB의 마이그레이션 계보는 별개이므로 덮어쓰지 않는다.

## v2.1 다음 단계 결과
이전 v2.0 ZIP은 provenance에 그대로 포함했다. DB 계보 비교는 reports/DB_LINEAGE.md, 자동 DB 검증은 db/runbooks/02_자동검증.md를 따른다. 로컬 정적·회귀 결과는 VALIDATION.json, 환경 사전 확인은 reports/db_preflight.json에 있다.
