# v2.2.0 — 2026-10-24
- PostgreSQL 16.2 확보 및 initdb 시도: root 실행 거부로 실제 DB NOT_RUN.
- PostgreSQL 16.1 grammar parser로 SQL 19개 파일 검사.
- 빈 백업 fingerprint·잘못된 서버 버전도 통과할 수 있던 증거 판정 로직 보완.
- 전용 Docker Compose·PowerShell 실행기·결과 수집 진입점 추가(실행 NOT_RUN).
- DB 접속 timeout 기본 5초 추가. SQL·증거 음성 회귀 검사 확대.
- 기존 제품 방향과 V001~V013 바이트 보존; v2.1 원본 ZIP 포함.

# v2.1.0 — 2026-10-24
- v2.0 전체 내용과 원본 ZIP을 포함한 누적 정본.
- 기존 저장소와 ZIP의 DB 계보·해시 비교; 배포 DB 이력 UNKNOWN 명시.
- 전용 임시 PostgreSQL 16 신규 설치·보안·합성 데이터 백업 복원 검증 도구 추가.
- 필수 단계 누락·skip·실패·복원 불일치·해시 변경을 실패로 처리하는 회귀 검사 추가.
- PostgreSQL 16 CI workflow 추가. GitHub 실행과 실제 DB 실행은 NOT_RUN.

# v2.0.0 — 2026-10-24
- ChurchOS를 사용자의 첫 앱·교회 운영·마케팅 중심으로 확정.
- 일곱 제품의 독립 설계·개발·DB 소유·배포와 API 연결 명시.
- JLAcademy를 제품 경계·API enum·이벤트·Today·앱 화면·후속 SQL에 추가.
- 지저스라이프 원은 내부 생태계 명칭으로 한정하고 화면 전제 제거.
- 관리자 웹·PWA·Headless 배포 계획을 앱 역할별 화면으로 통합.
- 과거 보고서·중복 논리 DDL·이전 검증기·원본 저장소 재분류 도구 제거.
- V001~V012 바이트 보존, V013 추가. 원격 Git 이력과 원본 ZIP 보존.
- 정본 설계 상태와 미검증 런타임·출시 상태 분리.
